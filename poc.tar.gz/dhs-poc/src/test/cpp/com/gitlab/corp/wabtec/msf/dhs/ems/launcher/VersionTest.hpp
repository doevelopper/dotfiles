#ifndef COM_GITLAB_CORP_WABTEC_MSF_DHS_EMS_LAUNCHER_VERSIONTEST_HPP
#define COM_GITLAB_CORP_WABTEC_MSF_DHS_EMS_LAUNCHER_VERSIONTEST_HPP

#include <com/gitlab/corp/wabtec/msf/dhs/ems/launcher/Version.hpp>
#include <com/gitlab/corp/wabtec/msf/dhs/ems/drivers/Test.hpp>
#include <memory>

namespace com::gitlab::corp::wabtec::msf::dhs::ems::launcher::test
{
class VersionTest : public ::testing::Test {
        LOG4CXX_DECLARE_STATIC_TEST_LOGGER
    public:
        VersionTest() noexcept;
        VersionTest(const VersionTest &) = default;
        VersionTest(VersionTest &&) = default;
        VersionTest &operator=(const VersionTest &) = default;
        VersionTest &operator=(VersionTest &&) = default;
        virtual ~VersionTest() noexcept;

        void SetUp() override;
        void TearDown() override;

    protected:
        std::unique_ptr<com::gitlab::corp::wabtec::msf::dhs::ems::launcher::Version> m_targetUnderTest;

    private:
};
} // namespace com::gitlab::corp::wabtec::msf::dhs::ems::launcher::test
#endif