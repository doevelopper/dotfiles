#ifndef COM_GITLAB_CORP_WABTEC_MSF_DHS_EMS_LAUNCHER_CHANNELTEST_HPP
#define COM_GITLAB_CORP_WABTEC_MSF_DHS_EMS_LAUNCHER_CHANNELTEST_HPP

// #include <com/gitlab/corp/wabtec/msf/dhs/ems/launcher/Channel.hpp>

namespace com::gitlab::corp::wabtec::msf::dhs::ems::launcher::test {
class ChannelTest {
public:
  ChannelTest() noexcept;
  ChannelTest(const ChannelTest &) = default;
  ChannelTest(ChannelTest &&) = default;
  ChannelTest &operator=(const ChannelTest &) = default;
  ChannelTest &operator=(ChannelTest &&) = default;
  virtual ~ChannelTest() noexcept;

protected:
private:
};
} // namespace com::gitlab::corp::wabtec::msf::dhs::ems::launcher::test
#endif