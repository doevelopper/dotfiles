#ifndef COM_GITLAB_CORP_WABTEC_MSF_DHS_EMS_LAUNCHER_METHODCALLERTEST_HPP
#define COM_GITLAB_CORP_WABTEC_MSF_DHS_EMS_LAUNCHER_METHODCALLERTEST_HPP

// #include <com/gitlab/corp/wabtec/msf/dhs/ems/launcher/MethodCaller.hpp>

namespace com::gitlab::corp::wabtec::msf::dhs::ems::launcher::test {
class MethodCallerTest {
public:
  MethodCallerTest() noexcept;
  MethodCallerTest(const MethodCallerTest &) = default;
  MethodCallerTest(MethodCallerTest &&) = default;
  MethodCallerTest &operator=(const MethodCallerTest &) = default;
  MethodCallerTest &operator=(MethodCallerTest &&) = default;
  virtual ~MethodCallerTest() noexcept;

protected:
private:
};
} // namespace com::gitlab::corp::wabtec::msf::dhs::ems::launcher::test
#endif