
#include <com/gitlab/corp/wabtec/msf/dhs/ems/launcher/AbstractOptionsManagerMock.hpp>

using namespace com::gitlab::corp::wabtec::msf::dhs::ems::launcher;
using namespace com::gitlab::corp::wabtec::msf::dhs::ems::launcher::test;

AbstractOptionsManagerMock::AbstractOptionsManagerMock() noexcept {}

AbstractOptionsManagerMock::~AbstractOptionsManagerMock() noexcept {}
