
#include <com/gitlab/corp/wabtec/msf/dhs/ems/drivers/GooleTestTestEventListener.hpp>

using namespace com::gitlab::corp::wabtec::msf::dhs::ems::drivers;

log4cxx::LoggerPtr GooleTestTestEventListener::logger = log4cxx::Logger::getLogger(
        std::string("com.gitlab.corp.wabtec.msf.dhs.ems.drivers.GooleTestTestEventListener"));

GooleTestTestEventListener::GooleTestTestEventListener() noexcept
{
        LOG4CXX_TRACE(logger, __LOG4CXX_FUNC__);
}

GooleTestTestEventListener::~GooleTestTestEventListener() noexcept
{
        //  gtest takes ownership of the TestEnvironment ptr - we don't delete it.
        //        LOG4CXX_TRACE(logger, __LOG4CXX_FUNC__);
}

void GooleTestTestEventListener::OnTestProgramStart(const ::testing::UnitTest &unit_test)
{
        LOG4CXX_TRACE(logger, __LOG4CXX_FUNC__);
        LOG4CXX_INFO(logger,
                     "%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");
        LOG4CXX_INFO(logger, "Total Test Suite: " << ::testing::UnitTest::GetInstance()->total_test_suite_count()
                                                  << " Test cases with at least one test: "
                                                  << ::testing::UnitTest::GetInstance()->test_suite_to_run_count());
        LOG4CXX_INFO(logger,
                     "%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");
}

void GooleTestTestEventListener::OnTestIterationStart(const ::testing::UnitTest &unit_test, int iteration)
{
        LOG4CXX_TRACE(logger, __LOG4CXX_FUNC__);
}

void GooleTestTestEventListener::OnEnvironmentsSetUpStart(const ::testing::UnitTest &unit_test)
{
        LOG4CXX_TRACE(logger, __LOG4CXX_FUNC__);
}

void GooleTestTestEventListener::OnEnvironmentsSetUpEnd(const ::testing::UnitTest &unit_test)
{
        LOG4CXX_TRACE(logger, __LOG4CXX_FUNC__);
}

void GooleTestTestEventListener::OnTestSuiteStart(const ::testing::TestSuite &test_suite)
{
        LOG4CXX_TRACE(logger, __LOG4CXX_FUNC__);
        LOG4CXX_DEBUG(logger, "RUN: " << test_suite.name());
}

void GooleTestTestEventListener::OnTestCaseStart(const ::testing::TestCase &test_case)
{
        LOG4CXX_TRACE(logger, __LOG4CXX_FUNC__);
        LOG4CXX_DEBUG(logger, ">--------------->>--------------->>--------------->>--------------->>--------------->");
        LOG4CXX_DEBUG(logger, "    " << ::testing::UnitTest::GetInstance()->current_test_case()->name() << "    "
                                     << test_case.test_to_run_count() << "/" << test_case.total_test_count());
        LOG4CXX_DEBUG(logger, ">--------------->>--------------->>--------------->>--------------->>--------------->");
}

void GooleTestTestEventListener::OnTestStart(const ::testing::TestInfo &test_info)
{
        LOG4CXX_TRACE(logger, __LOG4CXX_FUNC__);
        LOG4CXX_DEBUG(logger, test_info.test_suite_name() << "." << test_info.name());
        std::stringstream formatedTestInfo;
        formatedTestInfo << "Test : [" << test_info.name() << "]";
        formatedTestInfo << " Test suite: [" << test_info.test_suite_name() << "]";
        formatedTestInfo << " of test case [" << test_info.test_case_name() << "]";
        formatedTestInfo << " (" << ::testing::UnitTest::GetInstance()->test_case_to_run_count() << ")";

        if (test_info.value_param() != nullptr) {
                formatedTestInfo << " with value param [" << test_info.value_param() << "]";
        }

        if (test_info.type_param() != nullptr) {
                formatedTestInfo << " and with type param [" << test_info.type_param() << "]";
        }

        LOG4CXX_DEBUG(logger, "!!! " << formatedTestInfo.str() << " !!!");
}

void GooleTestTestEventListener::OnTestDisabled(const ::testing::TestInfo &test_info)
{
        LOG4CXX_TRACE(logger, __LOG4CXX_FUNC__);
}

void GooleTestTestEventListener::OnTestPartResult(const ::testing::TestPartResult &test_part_result)
{
        LOG4CXX_TRACE(logger, __LOG4CXX_FUNC__);
        std::string status = test_part_result.failed() ? "*** Failure***" : "Success !!!";
        if (test_part_result.failed()) {
                const std::string message = test_part_result.message();
                const std::string summary = test_part_result.summary();
                std::stringstream msg;

                if (test_part_result.file_name())
                        msg << test_part_result.file_name() << std::string(":");

                if (test_part_result.line_number() != -1)
                        msg << test_part_result.line_number() << std::string(":");

                if (!summary.empty()) {
                        if (msg) {
                                msg << std::string("\n");
                        }
                        msg << summary;
                }
                if (!summary.empty() && summary != message) {
                        if (msg) {
                                msg << std::string("\n");
                        }
                        msg << message;
                }
                LOG4CXX_ERROR(logger, "PARTIAL" << test_part_result.summary() << msg.str()
                                                << test_part_result.fatally_failed());
        }
}

void GooleTestTestEventListener::OnTestEnd(const ::testing::TestInfo &test_info)
{
        LOG4CXX_TRACE(logger, __LOG4CXX_FUNC__);

        std::stringstream formatedTestInfo;
        formatedTestInfo << " [Test suite: " << test_info.test_suite_name() << "] finished: ";
        formatedTestInfo << " Test : " << test_info.name();

        if (test_info.result()) {
                if (test_info.result()->Passed()) {
                        formatedTestInfo << " -> PASSED";
                }

                if (test_info.result()->Failed()) {
                        // if (GTEST_FLAG(list_tests))
                        // {
                        formatedTestInfo << " file [" << test_info.file() << "]";
                        formatedTestInfo << " line [" << test_info.line() << "]";
                        // }
                        formatedTestInfo << " -> FAILED";
                }
        }

        formatedTestInfo << " ";
        formatedTestInfo << (test_info.result())->elapsed_time() << " ms";

        LOG4CXX_INFO(logger, "Summary: " << formatedTestInfo.str());
}

void GooleTestTestEventListener::OnTestSuiteEnd(const ::testing::TestSuite &test_suite)
{
        LOG4CXX_TRACE(logger, __LOG4CXX_FUNC__);
        LOG4CXX_DEBUG(logger, "END RUN: " << test_suite.name());
}

void GooleTestTestEventListener::OnTestCaseEnd(const ::testing::TestCase &test_case)
{
        LOG4CXX_TRACE(logger, __LOG4CXX_FUNC__);
        LOG4CXX_DEBUG(logger, "<---------------<<---------------<<---------------<<---------------<<---------------");
        LOG4CXX_DEBUG(logger, "    " << ::testing::UnitTest::GetInstance()->current_test_case()->name() << "   "
                                     << test_case.elapsed_time() << " ms");
        LOG4CXX_DEBUG(logger, " Passed(" << test_case.successful_test_count() << ")"
                                         << " Failed(" << test_case.failed_test_count() << ")"
                                         << " Skipped(" << test_case.skipped_test_count() << ")"
                                         << " Disabled(" << test_case.disabled_test_count() << ")");
        LOG4CXX_DEBUG(logger, "<---------------<<---------------<<---------------<<---------------<<---------------");
}

void GooleTestTestEventListener::OnEnvironmentsTearDownStart(const ::testing::UnitTest &unit_test)
{
        LOG4CXX_TRACE(logger, __LOG4CXX_FUNC__);
}

void GooleTestTestEventListener::OnEnvironmentsTearDownEnd(const ::testing::UnitTest &unit_test)
{
        LOG4CXX_TRACE(logger, __LOG4CXX_FUNC__);
}

void GooleTestTestEventListener::OnTestIterationEnd(const ::testing::UnitTest &unit_test, int iteration)
{
        LOG4CXX_TRACE(logger, __LOG4CXX_FUNC__);
        LOG4CXX_DEBUG(logger, "Test Iteration  " << unit_test.Passed() << " Elapsed time " << unit_test.elapsed_time()
                                                 << " ms");
}

void GooleTestTestEventListener::OnTestProgramEnd(const ::testing::UnitTest &unit_test)
{
        LOG4CXX_TRACE(logger, __LOG4CXX_FUNC__);
        LOG4CXX_INFO(logger,
                     "%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");
        LOG4CXX_INFO(logger, unit_test.reportable_test_count()
                                     << " tests Executed: Passed(" << unit_test.successful_test_count() << "), Failed("
                                     << unit_test.failed_test_count() << ")"
                                     << ", Skipped(" << unit_test.skipped_test_count() << ")"
                                     << ", Disabled(" << unit_test.reportable_disabled_test_count() << ")"
                                     << " Duration: (" << unit_test.elapsed_time() << " ms)");
        LOG4CXX_INFO(logger,
                     "%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");
}
