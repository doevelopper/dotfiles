#ifndef COM_GITLAB_CORP_WABTEC_MSF_DHS_EMS_DRIVERS_TESTENVIRONMENTCONFIGURATOR_HPP
#define COM_GITLAB_CORP_WABTEC_MSF_DHS_EMS_DRIVERS_TESTENVIRONMENTCONFIGURATOR_HPP

#include <iostream>

#include <gtest/gtest.h>
#include <gmock/gmock.h>

#include <com/gitlab/corp/wabtec/msf/dhs/ems/logging/LoggingService.hpp>

namespace com::gitlab::corp::wabtec::msf::dhs::ems::drivers
{
class TestEnvironmentConfigurator : public ::testing::Environment {
        LOG4CXX_DECLARE_STATIC_LOGGER
    public:
        TestEnvironmentConfigurator() noexcept;
        TestEnvironmentConfigurator(const TestEnvironmentConfigurator &) = default;
        TestEnvironmentConfigurator(TestEnvironmentConfigurator &&) = default;
        TestEnvironmentConfigurator &operator=(const TestEnvironmentConfigurator &) = default;
        TestEnvironmentConfigurator &operator=(TestEnvironmentConfigurator &&) = default;
        virtual ~TestEnvironmentConfigurator() noexcept;

        void SetUp() override;
        void TearDown() override;

    protected:
    private:
};
} // namespace com::gitlab::corp::wabtec::msf::dhs::ems::drivers
#endif
