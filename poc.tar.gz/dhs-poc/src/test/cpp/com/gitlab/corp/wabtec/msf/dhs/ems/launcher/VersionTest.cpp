
#include <com/gitlab/corp/wabtec/msf/dhs/ems/launcher/VersionTest.hpp>

using namespace com::gitlab::corp::wabtec::msf::dhs::ems::launcher;
using namespace com::gitlab::corp::wabtec::msf::dhs::ems::launcher::test;

log4cxx::LoggerPtr VersionTest::logger =
        log4cxx::Logger::getLogger(std::string("com.gitlab.corp.wabtec.msf.dhs.ems.launcher.test.VersionTest"));

VersionTest::VersionTest() noexcept : m_targetUnderTest()
{
        LOG4CXX_TRACE(logger, __LOG4CXX_FUNC__);
}

VersionTest::~VersionTest() noexcept
{
        LOG4CXX_TRACE(logger, __LOG4CXX_FUNC__);
}

void VersionTest::SetUp()
{
        LOG4CXX_TRACE(logger, __LOG4CXX_FUNC__);
        m_targetUnderTest = std::make_unique<Version>();
}

void VersionTest::TearDown()
{
        LOG4CXX_TRACE(logger, __LOG4CXX_FUNC__);
}

TEST_F(VersionTest, Test_Not_Yet_Implemented)
{
        LOG4CXX_TRACE(logger, __LOG4CXX_FUNC__);
}