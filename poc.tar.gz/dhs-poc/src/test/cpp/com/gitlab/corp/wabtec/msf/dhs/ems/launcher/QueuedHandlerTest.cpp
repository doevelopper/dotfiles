
#include <com/gitlab/corp/wabtec/msf/dhs/ems/launcher/QueuedHandlerTest.hpp>

using namespace com::gitlab::corp::wabtec::msf::dhs::ems::launcher;
using namespace com::gitlab::corp::wabtec::msf::dhs::ems::launcher::test;

QueuedHandlerTest::QueuedHandlerTest() noexcept {}

QueuedHandlerTest::~QueuedHandlerTest() noexcept {}
