#ifndef COM_GITLAB_CORP_WABTEC_MSF_DHS_EMS_LAUNCHER_ABSTRACTOPTIONSMANAGERMOCK_HPP
#define COM_GITLAB_CORP_WABTEC_MSF_DHS_EMS_LAUNCHER_ABSTRACTOPTIONSMANAGERMOCK_HPP

// #include <com/gitlab/corp/wabtec/msf/dhs/ems/launcher/Executor.hpp>

namespace com::gitlab::corp::wabtec::msf::dhs::ems::launcher::test {
class AbstractOptionsManagerMock {
public:
  AbstractOptionsManagerMock() noexcept;
  AbstractOptionsManagerMock(const AbstractOptionsManagerMock &) = default;
  AbstractOptionsManagerMock(AbstractOptionsManagerMock &&) = default;
  AbstractOptionsManagerMock &
  operator=(const AbstractOptionsManagerMock &) = default;
  AbstractOptionsManagerMock &
  operator=(AbstractOptionsManagerMock &&) = default;
  virtual ~AbstractOptionsManagerMock() noexcept;

protected:
private:
};
} // namespace com::gitlab::corp::wabtec::msf::dhs::ems::launcher::test
#endif