
#include <com/gitlab/corp/wabtec/msf/dhs/ems/drivers/TestEnvironmentConfigurator.hpp>

using namespace com::gitlab::corp::wabtec::msf::dhs::ems::drivers;

log4cxx::LoggerPtr TestEnvironmentConfigurator::logger = log4cxx::Logger::getLogger(
        std::string("com.gitlab.corp.wabtec.msf.dhs.ems.drivers.TestEnvironmentConfigurator"));

TestEnvironmentConfigurator::TestEnvironmentConfigurator() noexcept
{
        LOG4CXX_TRACE(logger, __LOG4CXX_FUNC__);
}

TestEnvironmentConfigurator::~TestEnvironmentConfigurator() noexcept
{
        // gtest takes ownership of the TestEnvironment ptr - we don't delete it.
        //        LOG4CXX_TRACE(logger, __LOG4CXX_FUNC__);
}

void TestEnvironmentConfigurator::SetUp()
{
        LOG4CXX_TRACE(logger, __LOG4CXX_FUNC__);
}

void TestEnvironmentConfigurator::TearDown()
{
        LOG4CXX_TRACE(logger, __LOG4CXX_FUNC__);
}
