

#ifndef COM_GITLAB_CORP_WABTEC_MSF_DHS_EMS_DRIVERS_TEST_HPP
#define COM_GITLAB_CORP_WABTEC_MSF_DHS_EMS_DRIVERS_TEST_HPP

#include <iostream>

#include <gtest/gtest.h>
#include <gmock/gmock.h>

#include <com/gitlab/corp/wabtec/msf/dhs/ems/drivers/TestEventListenerConfigurator.hpp>
#include <com/gitlab/corp/wabtec/msf/dhs/ems/drivers/TestEnvironmentConfigurator.hpp>

namespace com::gitlab::corp::wabtec::msf::dhs::ems::drivers
{
class Test {
        LOG4CXX_DECLARE_STATIC_LOGGER
    public:
        Test() noexcept;
        Test(const Test &) = default;
        Test(Test &&) = default;
        Test &operator=(const Test &) = default;
        Test &operator=(Test &&) = default;
        virtual ~Test() noexcept;

        Test(std::string &suite, unsigned int iteration = 1) noexcept;
        bool setup(int argc, char *argv[]);
        int run(int argc = 0, char *argv[] = NULL);
        bool teardown();
        void moduleUnderTest(char *argv[]);
        void notYetImplemented();

    protected:
    private:
        std::string_view m_moduleUnderTest;
};
} // namespace com::gitlab::corp::wabtec::msf::dhs::ems::drivers
#endif
