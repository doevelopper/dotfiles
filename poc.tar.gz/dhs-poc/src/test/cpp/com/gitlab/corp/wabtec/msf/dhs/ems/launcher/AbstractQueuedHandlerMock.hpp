#ifndef COM_GITLAB_CORP_WABTEC_MSF_DHS_EMS_LAUNCHER_ABSTRACTQUEUEDHANDLERMOCK_HPP
#define COM_GITLAB_CORP_WABTEC_MSF_DHS_EMS_LAUNCHER_ABSTRACTQUEUEDHANDLERMOCK_HPP

// #include
// <com/gitlab/corp/wabtec/msf/dhs/ems/launcher/AbstractQueuedHandler.hpp>

namespace com::gitlab::corp::wabtec::msf::dhs::ems::launcher::test {
class AbstractQueuedHandlerMock {
public:
  AbstractQueuedHandlerMock() noexcept;
  AbstractQueuedHandlerMock(const AbstractQueuedHandlerMock &) = default;
  AbstractQueuedHandlerMock(AbstractQueuedHandlerMock &&) = default;
  AbstractQueuedHandlerMock &
  operator=(const AbstractQueuedHandlerMock &) = default;
  AbstractQueuedHandlerMock &operator=(AbstractQueuedHandlerMock &&) = default;
  virtual ~AbstractQueuedHandlerMock() noexcept;

protected:
private:
};
} // namespace com::gitlab::corp::wabtec::msf::dhs::ems::launcher::test
#endif