
#include <com/gitlab/corp/wabtec/msf/dhs/ems/launcher/AbstractQueuedHandlerMock.hpp>

using namespace com::gitlab::corp::wabtec::msf::dhs::ems::launcher;
using namespace com::gitlab::corp::wabtec::msf::dhs::ems::launcher::test;

AbstractQueuedHandlerMock::AbstractQueuedHandlerMock() noexcept {}

AbstractQueuedHandlerMock::~AbstractQueuedHandlerMock() noexcept {}
