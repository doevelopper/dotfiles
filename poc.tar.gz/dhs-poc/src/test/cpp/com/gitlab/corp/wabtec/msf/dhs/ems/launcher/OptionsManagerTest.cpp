
#include <com/gitlab/corp/wabtec/msf/dhs/ems/launcher/OptionsManagerTest.hpp>

using namespace com::gitlab::corp::wabtec::msf::dhs::ems::launcher;
using namespace com::gitlab::corp::wabtec::msf::dhs::ems::launcher::test;

OptionsManagerTest::OptionsManagerTest() noexcept {}

OptionsManagerTest::~OptionsManagerTest() noexcept {}
