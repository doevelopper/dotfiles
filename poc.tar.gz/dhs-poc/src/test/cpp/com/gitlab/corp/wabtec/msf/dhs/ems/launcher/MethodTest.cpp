
#include <com/gitlab/corp/wabtec/msf/dhs/ems/launcher/MethodTest.hpp>

using namespace com::gitlab::corp::wabtec::msf::dhs::ems::launcher;
using namespace com::gitlab::corp::wabtec::msf::dhs::ems::launcher::test;

MethodTest::MethodTest() noexcept {}

MethodTest::~MethodTest() noexcept {}
