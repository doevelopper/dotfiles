#ifndef COM_GITLAB_CORP_WABTEC_MSF_DHS_EMS_LAUNCHER_ABSTRACTQUEUEDHANDLERTEST_HPP
#define COM_GITLAB_CORP_WABTEC_MSF_DHS_EMS_LAUNCHER_ABSTRACTQUEUEDHANDLERTEST_HPP

#include <com/gitlab/corp/wabtec/msf/dhs/ems/launcher/AbstractQueuedHandlerMock.hpp>

namespace com::gitlab::corp::wabtec::msf::dhs::ems::launcher::test {
class AbstractQueuedHandlerTest {
public:
  AbstractQueuedHandlerTest() noexcept;
  AbstractQueuedHandlerTest(const AbstractQueuedHandlerTest &) = default;
  AbstractQueuedHandlerTest(AbstractQueuedHandlerTest &&) = default;
  AbstractQueuedHandlerTest &
  operator=(const AbstractQueuedHandlerTest &) = default;
  AbstractQueuedHandlerTest &operator=(AbstractQueuedHandlerTest &&) = default;
  virtual ~AbstractQueuedHandlerTest() noexcept;

protected:
private:
};
} // namespace com::gitlab::corp::wabtec::msf::dhs::ems::launcher::test
#endif