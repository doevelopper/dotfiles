
#include <com/gitlab/corp/wabtec/msf/dhs/ems/launcher/MethodCallerTest.hpp>

using namespace com::gitlab::corp::wabtec::msf::dhs::ems::launcher;
using namespace com::gitlab::corp::wabtec::msf::dhs::ems::launcher::test;

MethodCallerTest::MethodCallerTest() noexcept {}

MethodCallerTest::~MethodCallerTest() noexcept {}
