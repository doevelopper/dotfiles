#ifndef COM_GITLAB_CORP_WABTEC_MSF_DHS_EMS_LAUNCHER_IOPTIONSMANAGERMOCK_HPP
#define COM_GITLAB_CORP_WABTEC_MSF_DHS_EMS_LAUNCHER_IOPTIONSMANAGERMOCK_HPP

// #include <com/gitlab/corp/wabtec/msf/dhs/ems/launcher/Executor.hpp>

namespace com::gitlab::corp::wabtec::msf::dhs::ems::launcher::test {
class IOptionsManagerMock {
public:
  IOptionsManagerMock() noexcept;
  IOptionsManagerMock(const IOptionsManagerMock &) = default;
  IOptionsManagerMock(IOptionsManagerMock &&) = default;
  IOptionsManagerMock &operator=(const IOptionsManagerMock &) = default;
  IOptionsManagerMock &operator=(IOptionsManagerMock &&) = default;
  virtual ~IOptionsManagerMock() noexcept;

protected:
private:
};
} // namespace com::gitlab::corp::wabtec::msf::dhs::ems::launcher::test
#endif