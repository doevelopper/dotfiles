#ifndef COM_GITLAB_CORP_WABTEC_MSF_DHS_EMS_LAUNCHER_IPLUGINMOCK_HPP
#define COM_GITLAB_CORP_WABTEC_MSF_DHS_EMS_LAUNCHER_IPLUGINMOCK_HPP

// #include <com/gitlab/corp/wabtec/msf/dhs/ems/launcher/IPlugin.hpp>

namespace com::gitlab::corp::wabtec::msf::dhs::ems::launcher::test {
class IPluginMock {
public:
  IPluginMock() noexcept;
  IPluginMock(const IPluginMock &) = default;
  IPluginMock(IPluginMock &&) = default;
  IPluginMock &operator=(const IPluginMock &) = default;
  IPluginMock &operator=(IPluginMock &&) = default;
  virtual ~IPluginMock() noexcept;

protected:
private:
};
} // namespace com::gitlab::corp::wabtec::msf::dhs::ems::launcher::test
#endif