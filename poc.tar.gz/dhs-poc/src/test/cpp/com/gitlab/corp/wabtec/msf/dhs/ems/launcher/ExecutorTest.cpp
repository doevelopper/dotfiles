
#include <com/gitlab/corp/wabtec/msf/dhs/ems/launcher/ExecutorTest.hpp>

using namespace com::gitlab::corp::wabtec::msf::dhs::ems::launcher;
using namespace com::gitlab::corp::wabtec::msf::dhs::ems::launcher::test;

ExecutorTest::ExecutorTest() noexcept {}

ExecutorTest::~ExecutorTest() noexcept {}
