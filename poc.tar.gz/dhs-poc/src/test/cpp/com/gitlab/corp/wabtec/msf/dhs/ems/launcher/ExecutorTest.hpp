#ifndef COM_GITLAB_CORP_WABTEC_MSF_DHS_EMS_LAUNCHER_EXECUTORTEST_HPP
#define COM_GITLAB_CORP_WABTEC_MSF_DHS_EMS_LAUNCHER_EXECUTORTEST_HPP

// #include <com/gitlab/corp/wabtec/msf/dhs/ems/launcher/Executor.hpp>

namespace com::gitlab::corp::wabtec::msf::dhs::ems::launcher::test {
class ExecutorTest {
public:
  ExecutorTest() noexcept;
  ExecutorTest(const ExecutorTest &) = default;
  ExecutorTest(ExecutorTest &&) = default;
  ExecutorTest &operator=(const ExecutorTest &) = default;
  ExecutorTest &operator=(ExecutorTest &&) = default;
  virtual ~ExecutorTest() noexcept;

protected:
private:
};
} // namespace com::gitlab::corp::wabtec::msf::dhs::ems::launcher::test
#endif