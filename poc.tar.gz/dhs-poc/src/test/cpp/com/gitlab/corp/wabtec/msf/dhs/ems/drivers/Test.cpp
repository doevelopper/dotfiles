
#include "drivers/GooleTestTestEventListener.hpp"
#include "drivers/TestEnvironmentConfigurator.hpp"
#include "drivers/TestEventListenerConfigurator.hpp"
#include <com/gitlab/corp/wabtec/msf/dhs/ems/drivers/Test.hpp>
#include <gtest/gtest.h>

using namespace com::gitlab::corp::wabtec::msf::dhs::ems::drivers;

log4cxx::LoggerPtr Test::logger =
        log4cxx::Logger::getLogger(std::string("com.gitlab.corp.wabtec.msf.dhs.ems.drivers.Test"));

Test::Test() noexcept
{
        LOG4CXX_TRACE(logger, __LOG4CXX_FUNC__);
}

Test::Test(std::string &suite, unsigned int iteration) noexcept
{
        LOG4CXX_TRACE(logger, __LOG4CXX_FUNC__);
}

Test::~Test() noexcept
{
        LOG4CXX_TRACE(logger, __LOG4CXX_FUNC__);
}

bool Test::setup(int argc, char *argv[])
{
        LOG4CXX_TRACE(logger, __LOG4CXX_FUNC__);
        this->moduleUnderTest(argv);
        ::testing::InitGoogleMock(&argc, argv);

        //Diconnect printing
        //[==========] Running 0 tests from 0 test suites.
        //[==========] 0 tests from 0 test suites ran. (0 ms total)
        //[  PASSED  ] 0 tests.
        ::testing::TestEventListeners &listeners = testing::UnitTest::GetInstance()->listeners();
        auto default_printer = listeners.Release(listeners.default_result_printer());
        //        delete listeners.Release(listeners.default_result_printer());

        TestEventListenerConfigurator::Delegate(default_printer).build();
        listeners.Append(new GooleTestTestEventListener);
        ::testing::AddGlobalTestEnvironment(new TestEnvironmentConfigurator);
        return true;
}

int Test::run(int argc, char *argv[])
{
        LOG4CXX_TRACE(logger, __LOG4CXX_FUNC__);

        //        ::testing::InitGoogleMock(&argc, argv);
        //        this->setup();
        std::uint_fast64_t ret_val = RUN_ALL_TESTS();
        //        this->teardown();
        return (ret_val);
        return (EXIT_SUCCESS);
}

bool Test::teardown()
{
        return true;
}

void Test::moduleUnderTest(char *argv[])
{
        LOG4CXX_TRACE(logger, __LOG4CXX_FUNC__);

        auto sp = std::span<char>(argv[0], strlen(argv[0]));
        std::transform(sp.begin(), sp.end(), sp.begin(), [](char c) { return std::toupper(c); });
        const std::string runnerProcessName = std::string(sp.begin(), sp.end());
        std::string::size_type i = runnerProcessName.find("CPP");
        m_moduleUnderTest = runnerProcessName;
        m_moduleUnderTest.remove_prefix(m_moduleUnderTest.find_last_of('/') + 1);

        LOG4CXX_INFO(logger, "###################################################################");
        LOG4CXX_INFO(logger, "Module Under UnitTest:  " << m_moduleUnderTest);
        LOG4CXX_INFO(logger, "###################################################################");
}

void Test::notYetImplemented()
{
        LOG4CXX_TRACE(logger, __LOG4CXX_FUNC__);
        GTEST_NONFATAL_FAILURE_("Not YET implemented!!!!!!");
}