
#include <com/gitlab/corp/wabtec/msf/dhs/ems/launcher/IOptionsManagerMock.hpp>

using namespace com::gitlab::corp::wabtec::msf::dhs::ems::launcher;
using namespace com::gitlab::corp::wabtec::msf::dhs::ems::launcher::test;

IOptionsManagerMock::IOptionsManagerMock() noexcept {}

IOptionsManagerMock::~IOptionsManagerMock() noexcept {}
