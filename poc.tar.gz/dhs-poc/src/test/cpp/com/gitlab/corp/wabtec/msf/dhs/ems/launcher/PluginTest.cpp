
#include <com/gitlab/corp/wabtec/msf/dhs/ems/launcher/PluginTest.hpp>

using namespace com::gitlab::corp::wabtec::msf::dhs::ems::launcher;
using namespace com::gitlab::corp::wabtec::msf::dhs::ems::launcher::test;

PluginTest::PluginTest() noexcept {}

PluginTest::~PluginTest() noexcept {}
