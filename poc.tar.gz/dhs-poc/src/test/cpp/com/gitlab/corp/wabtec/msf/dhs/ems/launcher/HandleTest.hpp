#ifndef COM_GITLAB_CORP_WABTEC_MSF_DHS_EMS_LAUNCHER_HANDLETEST_HPP
#define COM_GITLAB_CORP_WABTEC_MSF_DHS_EMS_LAUNCHER_HANDLETEST_HPP

// #include <com/gitlab/corp/wabtec/msf/dhs/ems/launcher/Handle.hpp>

namespace com::gitlab::corp::wabtec::msf::dhs::ems::launcher::test {
class HandleTest {
public:
  HandleTest() noexcept;
  HandleTest(const HandleTest &) = default;
  HandleTest(HandleTest &&) = default;
  HandleTest &operator=(const HandleTest &) = default;
  HandleTest &operator=(HandleTest &&) = default;
  virtual ~HandleTest() noexcept;

protected:
private:
};
} // namespace com::gitlab::corp::wabtec::msf::dhs::ems::launcher::test
#endif