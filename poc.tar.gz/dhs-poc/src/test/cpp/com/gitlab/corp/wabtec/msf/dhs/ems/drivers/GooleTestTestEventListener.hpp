#ifndef COM_GITLAB_CORP_WABTEC_MSF_DHS_EMS_DRIVERS_GOOLETESTTESTEVENTLISTENER_HPP
#define COM_GITLAB_CORP_WABTEC_MSF_DHS_EMS_DRIVERS_GOOLETESTTESTEVENTLISTENER_HPP

#include <iostream>
#include <memory>

#include <gtest/gtest.h>
#include <gmock/gmock.h>

#include <com/gitlab/corp/wabtec/msf/dhs/ems/logging/LoggingService.hpp>

namespace com::gitlab::corp::wabtec::msf::dhs::ems::drivers
{
class GooleTestTestEventListener : public ::testing::EmptyTestEventListener {
        LOG4CXX_DECLARE_STATIC_LOGGER
    public:
        GooleTestTestEventListener() noexcept;
        GooleTestTestEventListener(const GooleTestTestEventListener &) = default;
        GooleTestTestEventListener(GooleTestTestEventListener &&) = default;
        GooleTestTestEventListener &operator=(const GooleTestTestEventListener &) = default;
        GooleTestTestEventListener &operator=(GooleTestTestEventListener &&) = default;
        virtual ~GooleTestTestEventListener() noexcept;

        void OnTestProgramStart(const ::testing::UnitTest & /*unit_test*/) override;
        void OnTestIterationStart(const ::testing::UnitTest & /*unit_test*/, int /*iteration*/) override;
        void OnEnvironmentsSetUpStart(const ::testing::UnitTest & /*unit_test*/) override;
        void OnEnvironmentsSetUpEnd(const ::testing::UnitTest & /*unit_test*/) override;
        void OnTestSuiteStart(const ::testing::TestSuite & /*test_suite*/) override;
        void OnTestCaseStart(const ::testing::TestCase & /*test_case*/) override;
        void OnTestStart(const ::testing::TestInfo & /*test_info*/) override;
        void OnTestDisabled(const ::testing::TestInfo & /*test_info*/) override;
        void OnTestPartResult(const ::testing::TestPartResult & /*test_part_result*/) override;
        void OnTestEnd(const ::testing::TestInfo & /*test_info*/) override;
        void OnTestSuiteEnd(const ::testing::TestSuite & /*test_suite*/) override;
        void OnTestCaseEnd(const ::testing::TestCase & /*test_case*/) override;
        void OnEnvironmentsTearDownStart(const ::testing::UnitTest & /*unit_test*/) override;
        void OnEnvironmentsTearDownEnd(const ::testing::UnitTest & /*unit_test*/) override;
        void OnTestIterationEnd(const ::testing::UnitTest & /*unit_test*/, int /*iteration*/) override;
        void OnTestProgramEnd(const ::testing::UnitTest & /*unit_test*/) override;

    protected:
    private:
};
} // namespace com::gitlab::corp::wabtec::msf::dhs::ems::drivers
#endif
