#ifndef COM_GITLAB_CORP_WABTEC_MSF_DHS_EMS_LAUNCHER_METHODTEST_HPP
#define COM_GITLAB_CORP_WABTEC_MSF_DHS_EMS_LAUNCHER_METHODTEST_HPP

// #include <com/gitlab/corp/wabtec/msf/dhs/ems/launcher/Method.hpp>

namespace com::gitlab::corp::wabtec::msf::dhs::ems::launcher::test {
class MethodTest {
public:
  MethodTest() noexcept;
  MethodTest(const MethodTest &) = default;
  MethodTest(MethodTest &&) = default;
  MethodTest &operator=(const MethodTest &) = default;
  MethodTest &operator=(MethodTest &&) = default;
  virtual ~MethodTest() noexcept;

protected:
private:
};
} // namespace com::gitlab::corp::wabtec::msf::dhs::ems::launcher::test
#endif