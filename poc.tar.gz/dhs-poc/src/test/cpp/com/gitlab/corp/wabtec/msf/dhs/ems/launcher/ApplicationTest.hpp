#ifndef COM_GITLAB_CORP_WABTEC_MSF_DHS_EMS_LAUNCHER_APPLICATIONTEST_HPP
#define COM_GITLAB_CORP_WABTEC_MSF_DHS_EMS_LAUNCHER_APPLICATIONTEST_HPP

//#include <com/gitlab/corp/wabtec/msf/dhs/ems/launcher/Application.hpp>

namespace com::gitlab::corp::wabtec::msf::dhs::ems::launcher::test {
class ApplicationTest {
public:
  ApplicationTest() noexcept;
  ApplicationTest(const ApplicationTest &) = default;
  ApplicationTest(ApplicationTest &&) = default;
  ApplicationTest &operator=(const ApplicationTest &) = default;
  ApplicationTest &operator=(ApplicationTest &&) = default;
  virtual ~ApplicationTest() noexcept;

protected:
private:
};
} // namespace com::gitlab::corp::wabtec::msf::dhs::ems::launcher::test
#endif