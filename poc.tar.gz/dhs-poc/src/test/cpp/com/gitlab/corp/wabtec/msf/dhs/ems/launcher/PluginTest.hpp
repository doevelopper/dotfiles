#ifndef COM_GITLAB_CORP_WABTEC_MSF_DHS_EMS_LAUNCHER_PLUGINTEST_HPP
#define COM_GITLAB_CORP_WABTEC_MSF_DHS_EMS_LAUNCHER_PLUGINTEST_HPP

// #include <com/gitlab/corp/wabtec/msf/dhs/ems/launcher/Plugin.hpp>

namespace com::gitlab::corp::wabtec::msf::dhs::ems::launcher::test {
class PluginTest {
public:
  PluginTest() noexcept;
  PluginTest(const PluginTest &) = default;
  PluginTest(PluginTest &&) = default;
  PluginTest &operator=(const PluginTest &) = default;
  PluginTest &operator=(PluginTest &&) = default;
  virtual ~PluginTest() noexcept;

protected:
private:
};
} // namespace com::gitlab::corp::wabtec::msf::dhs::ems::launcher::test
#endif