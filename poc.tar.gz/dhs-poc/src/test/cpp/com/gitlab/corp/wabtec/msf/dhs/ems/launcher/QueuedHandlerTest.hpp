#ifndef COM_GITLAB_CORP_WABTEC_MSF_DHS_EMS_LAUNCHER_QUEUEDHANDLERTEST_HPP
#define COM_GITLAB_CORP_WABTEC_MSF_DHS_EMS_LAUNCHER_QUEUEDHANDLERTEST_HPP

// #include <com/gitlab/corp/wabtec/msf/dhs/ems/launcher/QueuedHandler.hpp>

namespace com::gitlab::corp::wabtec::msf::dhs::ems::launcher::test {
class QueuedHandlerTest {
public:
  QueuedHandlerTest() noexcept;
  QueuedHandlerTest(const QueuedHandlerTest &) = default;
  QueuedHandlerTest(QueuedHandlerTest &&) = default;
  QueuedHandlerTest &operator=(const QueuedHandlerTest &) = default;
  QueuedHandlerTest &operator=(QueuedHandlerTest &&) = default;
  virtual ~QueuedHandlerTest() noexcept;

protected:
private:
};
} // namespace com::gitlab::corp::wabtec::msf::dhs::ems::launcher::test
#endif