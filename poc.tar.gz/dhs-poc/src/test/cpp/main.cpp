
#include <cstdlib>
#include <iostream>
#include <com/gitlab/corp/wabtec/msf/dhs/ems/drivers/Test.hpp>

using namespace com::gitlab::corp::wabtec::msf::dhs::ems::drivers;
using namespace com::gitlab::corp::wabtec::msf::dhs::ems::launcher::logging;
/*!
 * @brief  Main entry poinbt of the application
 * @param[in] argc number of string arguments passed via argv
 * @param[in,out] argv array to command line arguments as strings
 *             (an array of character pointers)
 * @return The completion status code (zero indicates success)
 */
int main([[maybe_unused]] int argc, [[maybe_unused]] char *argv[])
{
        std::uint8_t runStatus = EXIT_FAILURE;
        char loggersConfiguratorPath[]="TEMP=/opt/log4cxx.xml";
        putenv( loggersConfiguratorPath );
        
        std::unique_ptr<LoggingService> loggingService =std::make_unique<LoggingService>();
        std::unique_ptr<Test> objectUderTest = std::make_unique<Test>();//        Test *objectUderTest = new Test();

        try {
                objectUderTest->setup(argc, argv);

                runStatus = objectUderTest->run(argc, argv);

                objectUderTest->teardown();

        } catch (const std::exception &e) {
          LOG4CXX_ERROR(log4cxx::Logger::getRootLogger(), "A standars exception occured: " << e.what());
        } catch (...) {
          LOG4CXX_ERROR(log4cxx::Logger::getRootLogger(), "UNKNOWN EXCEPTION Occured ..."); 
        }

        if (runStatus != EXIT_SUCCESS) {
                LOG4CXX_ERROR(log4cxx::Logger::getRootLogger(), "⠀⠀⠀⣠⣶⣾⢿⡿⣿⣟⡿⣿⢿⡿⣿⣟⡷⣶⢶⣦⣤⣄⣀⡀⢀⣴⣶⡶⣶⢶⣦⡀"); 
                LOG4CXX_ERROR(log4cxx::Logger::getRootLogger(), "⠀⠀⢸⣟⣷⢯⣿⣻⢷⣯⢿⣯⢿⣽⣷⣻⢿⡽⣟⣾⣽⣻⢿⡅⢸⣿⣳⡿⣯⣟⣿⠆"); 
                LOG4CXX_ERROR(log4cxx::Logger::getRootLogger(), "⠀⠀⣸⣿⣼⢿⣧⢿⡿⣼⣿⣻⢿⣼⢧⣿⣟⣿⢿⣻⣼⣟⡿⡇⢸⡿⣧⣿⣻⢿⣼⠄"); 
                LOG4CXX_ERROR(log4cxx::Logger::getRootLogger(), "⢠⣾⣿⣳⣯⣿⢾⡿⣽⣟⣾⡽⣟⣯⣿⢾⣽⡾⣟⡿⣾⣽⣻⡅⢸⣿⣽⢾⣻⣯⣿⠂"); 
                LOG4CXX_ERROR(log4cxx::Logger::getRootLogger(), "⠈⢿⣞⣷⣟⡾⣿⡽⣟⣾⢯⣟⣿⣳⣯⡿⣞⣿⡽⣟⣷⣯⢿⡅⢸⣿⣞⣿⣽⣞⣿⠄"); 
                LOG4CXX_ERROR(log4cxx::Logger::getRootLogger(), "⣠⣿⣟⣾⣽⣻⢷⣟⡿⣽⣻⣟⣾⣽⣳⣿⣻⢷⣟⣿⣳⣯⢿⡃⢸⣷⢿⣞⣷⣯⣿⠄"); 
                LOG4CXX_ERROR(log4cxx::Logger::getRootLogger(), "⢻⣟⣾⣽⢾⣻⣟⣾⣟⣿⣳⣯⣟⣾⣟⣾⡽⣿⣞⣯⣷⣟⣿⡃⢸⣿⣻⢾⣻⡾⣽⠆"); 
                LOG4CXX_ERROR(log4cxx::Logger::getRootLogger(), "⢠⣿⣻⢾⡿⣽⣾⣻⢾⣳⣟⣷⣯⡷⣿⣞⣿⣳⣯⣟⣾⣽⠾⠇⠸⣿⣽⣻⢷⣿⣻⠇"); 
                LOG4CXX_ERROR(log4cxx::Logger::getRootLogger(), "⣿⣿⣹⢿⣹⡿⣾⣹⡿⣏⣿⡾⣷⣿⢷⣏⣷⡿⣷⣏⡿⠁⠀⠀⠀⠀⠀⠁⠈"); 
                LOG4CXX_ERROR(log4cxx::Logger::getRootLogger(), "⠙⣷⢿⣻⣽⢿⡽⣷⣟⡿⣞⣿⣳⣯⡿⣯⢿⣽⡷⡟"); 
                LOG4CXX_ERROR(log4cxx::Logger::getRootLogger(), "⠀⠀⠉⠉⠉⠋⠙⠃⠋⠙⠙⣷⣟⡷⣟⣿⣻⣾⡝"); 
                LOG4CXX_ERROR(log4cxx::Logger::getRootLogger(), "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢠⣿⢯⣟⣿⣳⢿⡾"); 
                LOG4CXX_ERROR(log4cxx::Logger::getRootLogger(), "⠀⠀⠀⠀⠀⠀⠀⠀⠀⢠⣿⣟⣯⡿⣞⡿⠋"); 
                LOG4CXX_ERROR(log4cxx::Logger::getRootLogger(), "⠀⠀⠀⠀⠀⠀⠀⠀⢀⣿⣟⣾⣽⣻⠏"); 
                LOG4CXX_ERROR(log4cxx::Logger::getRootLogger(), "⠀⠀⠀⠀⠀⠀⠀⠀⢸⣿⣾⣽⣾⡏"); 
                LOG4CXX_ERROR(log4cxx::Logger::getRootLogger(), "⠀⠀⠀⠀⠀⠀⠀⠀⠸⣟⣾⡽⣷⠇"); 
                LOG4CXX_ERROR(log4cxx::Logger::getRootLogger(), "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠹⢯⣿⣽"); 
                LOG4CXX_ERROR(log4cxx::Logger::getRootLogger(), "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢈⣉"); 
        } else {
                LOG4CXX_INFO(log4cxx::Logger::getRootLogger(), "                 █████");
                LOG4CXX_INFO(log4cxx::Logger::getRootLogger(), "           ███████"); 
                LOG4CXX_INFO(log4cxx::Logger::getRootLogger(), "          ███   ██"); 
                LOG4CXX_INFO(log4cxx::Logger::getRootLogger(), "          ██    ██"); 
                LOG4CXX_INFO(log4cxx::Logger::getRootLogger(), "         ███    ███"); 
                LOG4CXX_INFO(log4cxx::Logger::getRootLogger(), "         ███    ███"); 
                LOG4CXX_INFO(log4cxx::Logger::getRootLogger(), "          ██     ███"); 
                LOG4CXX_INFO(log4cxx::Logger::getRootLogger(), "          ███     ███"); 
                LOG4CXX_INFO(log4cxx::Logger::getRootLogger(), "           ███     ████"); 
                LOG4CXX_INFO(log4cxx::Logger::getRootLogger(), "            ██      ████"); 
                LOG4CXX_INFO(log4cxx::Logger::getRootLogger(), "            ███       ███"); 
                LOG4CXX_INFO(log4cxx::Logger::getRootLogger(), "             ███       ███"); 
                LOG4CXX_INFO(log4cxx::Logger::getRootLogger(), "             ███        ███"); 
                LOG4CXX_INFO(log4cxx::Logger::getRootLogger(), "              ██          ███"); 
                LOG4CXX_INFO(log4cxx::Logger::getRootLogger(), "          ███ ███          ██"); 
                LOG4CXX_INFO(log4cxx::Logger::getRootLogger(), "     ████████████           ███"); 
                LOG4CXX_INFO(log4cxx::Logger::getRootLogger(), "   ████████                  ███"); 
                LOG4CXX_INFO(log4cxx::Logger::getRootLogger(), "  ███                         █████████"); 
                LOG4CXX_INFO(log4cxx::Logger::getRootLogger(), " ███    █████████                  █████"); 
                LOG4CXX_INFO(log4cxx::Logger::getRootLogger(), " ██   ███████ ████                   ███"); 
                LOG4CXX_INFO(log4cxx::Logger::getRootLogger(), " ██    ███       ███                  ██"); 
                LOG4CXX_INFO(log4cxx::Logger::getRootLogger(), " ███           █████                  ██"); 
                LOG4CXX_INFO(log4cxx::Logger::getRootLogger(), "  ███       ████████                  ██"); 
                LOG4CXX_INFO(log4cxx::Logger::getRootLogger(), "   ████████████   ████                ██"); 
                LOG4CXX_INFO(log4cxx::Logger::getRootLogger(), "  ███ ██████       ████               ██"); 
                LOG4CXX_INFO(log4cxx::Logger::getRootLogger(), " ███           ██████                ██"); 
                LOG4CXX_INFO(log4cxx::Logger::getRootLogger(), "   ████ ████ ██████████               ██"); 
                LOG4CXX_INFO(log4cxx::Logger::getRootLogger(), "    ████████████     ███             ███"); 
                LOG4CXX_INFO(log4cxx::Logger::getRootLogger(), "     ██           ███████       ███████"); 
                LOG4CXX_INFO(log4cxx::Logger::getRootLogger(), "     ████      ████████        ████████"); 
                LOG4CXX_INFO(log4cxx::Logger::getRootLogger(), "      ████████████   ███     ███"); 
                LOG4CXX_INFO(log4cxx::Logger::getRootLogger(), "         ███ █ █      ███   ███"); 
                LOG4CXX_INFO(log4cxx::Logger::getRootLogger(), "         ███      █████  █████"); 
                LOG4CXX_INFO(log4cxx::Logger::getRootLogger(), "          ██████████████████"); 
                LOG4CXX_INFO(log4cxx::Logger::getRootLogger(), "           ██████████████"); 
                LOG4CXX_INFO(log4cxx::Logger::getRootLogger(), "                             "); 
        }

        return (runStatus == 0 ? EXIT_SUCCESS : EXIT_FAILURE);
}