#ifndef COM_GITLAB_CORP_WABTEC_MSF_DHS_EMS_LAUNCHER_LOGGINGSERVICE_HPP
#define COM_GITLAB_CORP_WABTEC_MSF_DHS_EMS_LAUNCHER_LOGGINGSERVICE_HPP

#include <log4cxx/logger.h>

#include <com/gitlab/corp/wabtec/msf/dhs/ems/utils/Visibility.hpp>

#define LOG4CXX_DECLARE_STATIC_LOGGER                                                                                  \
    private:                                                                                                           \
        static log4cxx::LoggerPtr logger;

#define LOG4CXX_DECLARE_CLASS_LOGGER(name)                                                                             \
    private:                                                                                                           \
        log4cxx::LoggerPtr name;

#define LOG4CXX_DECLARE_STATIC_TEST_LOGGER                                                                             \
    protected:                                                                                                         \
        static log4cxx::LoggerPtr logger;

#define LOG4CXX_DEFINE_CLASS_LOGGER(name) log4cxx::Logger::getLogger(std::string(boost::core::demangle(name)));

#define DEFINE_LOGGER std::string logger{ boost::typeindex::type_id<decltype(*this)>().pretty_name() };

namespace com::gitlab::corp::wabtec::msf::dhs::ems::launcher::logging
{
class LoggingService {
    public:
        LoggingService() noexcept;
        LoggingService(const LoggingService &) = default;
        LoggingService(LoggingService &&) = default;
        LoggingService &operator=(const LoggingService &) = default;
        LoggingService &operator=(LoggingService &&) = default;
        virtual ~LoggingService() noexcept;

    protected:
    private:
};
} // namespace com::gitlab::corp::wabtec::msf::dhs::ems::launcher::loggingg
#endif