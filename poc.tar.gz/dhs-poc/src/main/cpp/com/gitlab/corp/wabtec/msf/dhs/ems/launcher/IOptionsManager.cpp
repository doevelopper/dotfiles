
#include <com/gitlab/corp/wabtec/msf/dhs/ems/launcher/IOptionsManager.hpp>

using namespace com::gitlab::corp::wabtec::msf::dhs::ems::launcher;

IOptionsManager::IOptionsManager() noexcept
{
}

IOptionsManager::~IOptionsManager() noexcept
{
}
