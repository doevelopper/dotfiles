#ifndef COM_GITLAB_CORP_WABTEC_MSF_DHS_EMS_LAUNCHER_HANDLE_HPP
#define COM_GITLAB_CORP_WABTEC_MSF_DHS_EMS_LAUNCHER_HANDLE_HPP

namespace com::gitlab::corp::wabtec::msf::dhs::ems::launcher
{

template <typename Data, typename Policy> class Channel;

class Handle {
    public:
        Handle() noexcept;
        Handle(const Handle &) = default;
        Handle(Handle &&) = default;
        Handle &operator=(const Handle &) = default;
        Handle &operator=(Handle &&) = default;
        virtual ~Handle() noexcept;

    protected:
    private:
        template <typename Data, typename Policy> friend class Channel;
};
} // namespace com::gitlab::corp::wabtec::msf::dhs::ems::launcher
#endif