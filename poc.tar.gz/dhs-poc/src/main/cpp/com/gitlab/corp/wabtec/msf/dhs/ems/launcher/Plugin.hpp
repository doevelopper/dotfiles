#ifndef COM_GITLAB_CORP_WABTEC_MSF_DHS_EMS_LAUNCHER_PLUGIN_HPP
#define COM_GITLAB_CORP_WABTEC_MSF_DHS_EMS_LAUNCHER_PLUGIN_HPP

#include <boost/core/demangle.hpp>
#include <com/gitlab/corp/wabtec/msf/dhs/ems/launcher/IPlugin.hpp>

namespace com::gitlab::corp::wabtec::msf::dhs::ems::launcher
{
template <typename I> class Plugin : public IPlugin {
    public:
        Plugin() noexcept;
        Plugin(const Plugin &) = default;
        Plugin(Plugin &&) = default;
        Plugin &operator=(const Plugin &) = default;
        Plugin &operator=(Plugin &&) = default;
        virtual ~Plugin() noexcept;

        virtual void handleSignalHangUp() override;
        virtual const std::string &name() const override;
        virtual void startup() override;
        virtual void shutdown() override;
        virtual State state() const override;
        virtual void options(boost::program_options::options_description &command,
                             boost::program_options::options_description &config) override;
        virtual void initialize(const boost::program_options::variables_map &options) override;

    protected:
        Plugin(const std::string &name);

    private:
        std::string m_name;
        State m_state;
};
} // namespace com::gitlab::corp::wabtec::msf::dhs::ems::launcher
#endif