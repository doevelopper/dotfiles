
#include <com/gitlab/corp/wabtec/msf/dhs/ems/launcher/Version.hpp>

using namespace com::gitlab::corp::wabtec::msf::dhs::ems::launcher;

log4cxx::LoggerPtr Version::logger =
        log4cxx::Logger::getLogger(std::string("com.gitlab.corp.wabtec.msf.dhs.ems.launcher.Version"));

Version::Version() noexcept
{
        LOG4CXX_TRACE(logger, __LOG4CXX_FUNC__);
}

Version::~Version() noexcept
{
        LOG4CXX_TRACE(logger, __LOG4CXX_FUNC__);
}
