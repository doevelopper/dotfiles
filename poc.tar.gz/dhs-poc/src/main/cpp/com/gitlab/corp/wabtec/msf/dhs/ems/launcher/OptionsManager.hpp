#ifndef COM_GITLAB_CORP_WABTEC_MSF_DHS_EMS_LAUNCHER_OPTIONSMANAGER_HPP
#define COM_GITLAB_CORP_WABTEC_MSF_DHS_EMS_LAUNCHER_OPTIONSMANAGER_HPP

namespace com::gitlab::corp::wabtec::msf::dhs::ems::launcher
{
class OptionsManager {
    public:
        OptionsManager() noexcept;
        OptionsManager(const OptionsManager &) = default;
        OptionsManager(OptionsManager &&) = default;
        OptionsManager &operator=(const OptionsManager &) = default;
        OptionsManager &operator=(OptionsManager &&) = default;
        virtual ~OptionsManager() noexcept;

    protected:
    private:
};
} // namespace com::gitlab::corp::wabtec::msf::dhs::ems::launcher
#endif