
#include <com/gitlab/corp/wabtec/msf/dhs/ems/launcher/Executor.hpp>

using namespace com::gitlab::corp::wabtec::msf::dhs::ems::launcher;

Executor::Executor() noexcept
{
}

Executor::~Executor() noexcept
{
}
