
#include <com/gitlab/corp/wabtec/msf/dhs/ems/launcher/Method.hpp>

using namespace com::gitlab::corp::wabtec::msf::dhs::ems::launcher;

Method::Method() noexcept
{
}

Method::~Method() noexcept
{
}
