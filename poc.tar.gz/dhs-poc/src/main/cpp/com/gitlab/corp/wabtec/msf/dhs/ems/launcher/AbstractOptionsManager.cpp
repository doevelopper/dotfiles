
#include <com/gitlab/corp/wabtec/msf/dhs/ems/launcher/AbstractOptionsManager.hpp>

using namespace com::gitlab::corp::wabtec::msf::dhs::ems::launcher;

AbstractOptionsManager::AbstractOptionsManager() noexcept
{
}

AbstractOptionsManager::~AbstractOptionsManager() noexcept
{
}
