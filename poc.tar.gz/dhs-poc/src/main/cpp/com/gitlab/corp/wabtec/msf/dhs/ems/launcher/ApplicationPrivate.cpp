#include <iostream>
#include <unordered_map>

#include <boost/algorithm/string.hpp>
#include <boost/filesystem.hpp>
#include <boost/asio/signal_set.hpp>

#include <com/gitlab/corp/wabtec/msf/dhs/ems/launcher/ApplicationPrivate.hpp>

using namespace com::gitlab::corp::wabtec::msf::dhs::ems::launcher;
//std::cout << __func__ << __FUNCTION__ << __PRETTY_FUNCTION__ << std::endl;
ApplicationPrivate::ApplicationPrivate() noexcept
{
        std::cout << __PRETTY_FUNCTION__ << std::endl;
}

ApplicationPrivate::~ApplicationPrivate() noexcept
{
        std::cout << __PRETTY_FUNCTION__ << std::endl;
}
