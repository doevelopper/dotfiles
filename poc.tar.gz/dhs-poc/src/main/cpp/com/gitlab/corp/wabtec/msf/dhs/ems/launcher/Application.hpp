#ifndef COM_GITLAB_CORP_WABTEC_MSF_DHS_EMS_LAUNCHER_APPLICATION_HPP
#define COM_GITLAB_CORP_WABTEC_MSF_DHS_EMS_LAUNCHER_APPLICATION_HPP

#include <boost/core/demangle.hpp>
#include <boost/filesystem/path.hpp>
#include <boost/serialization/singleton.hpp>

#include <typeindex>

#include <com/gitlab/corp/wabtec/msf/dhs/ems/logging/LoggingService.hpp>

namespace com::gitlab::corp::wabtec::msf::dhs::ems::launcher
{

class ApplicationPrivate;

class Application {
        LOG4CXX_DECLARE_STATIC_LOGGER
    public:
        Application() noexcept;
        Application(const Application &) = default;
        Application(Application &&) = default;
        Application &operator=(const Application &) = default;
        Application &operator=(Application &&) = default;
        virtual ~Application() noexcept;

    protected:
    private:
        //      com::gitlab::corp::wabtec::msf::dhs::ems::launcher::logging::LoggingService *m_loggingService;
        std::unique_ptr<com::gitlab::corp::wabtec::msf::dhs::ems::launcher::logging::LoggingService> m_loggingService;
//        std::unique_ptr<ApplicationPrivate>()
};
} // namespace com::gitlab::corp::wabtec::msf::dhs::ems::launcher
#endif