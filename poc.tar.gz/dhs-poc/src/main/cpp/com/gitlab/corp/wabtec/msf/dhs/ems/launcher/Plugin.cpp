
#include "com/gitlab/corp/wabtec/msf/dhs/ems/launcher/IPlugin.hpp"
#include <com/gitlab/corp/wabtec/msf/dhs/ems/launcher/Plugin.hpp>

using namespace com::gitlab::corp::wabtec::msf::dhs::ems::launcher;

template <typename I>
Plugin<I>::Plugin() noexcept : m_name(boost::core::demangle(typeid(I).name())), m_state(Plugin<I>::State::REGISTERED)
{
}

template <typename I> Plugin<I>::Plugin(const std::string &name) : m_name(name), m_state(Plugin<I>::State::REGISTERED)
{
}

template <typename I> Plugin<I>::~Plugin() noexcept
{
}

template <typename I> void Plugin<I>::handleSignalHangUp()
{
}

template <typename I> const std::string &Plugin<I>::name() const
{
}

template <typename I> void Plugin<I>::startup()
{
}

template <typename I> void Plugin<I>::shutdown()
{
        if (m_state == IPlugin::State::STARTED) {
                m_state = IPlugin::State::STOPPED;
                static_cast<I *>(this)->shutdown();
        }
}

template <typename I> Plugin<I>::State Plugin<I>::state() const
{
}

template <typename I>
void Plugin<I>::options(boost::program_options::options_description &cli,
                        boost::program_options::options_description &cfg)
{
}

template <typename I> void Plugin<I>::initialize(const boost::program_options::variables_map &options)
{
}