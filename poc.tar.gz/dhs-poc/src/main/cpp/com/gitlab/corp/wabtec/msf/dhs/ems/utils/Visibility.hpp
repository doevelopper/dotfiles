#ifndef COM_GITLAB_CORP_WABTEC_MSF_DHS_EMS_UTILS_VISIBILITY_HPP
#define COM_GITLAB_CORP_WABTEC_MSF_DHS_EMS_UTILS_VISIBILITY_HPP

/* C++ compiler needs to know that types and declarations are C, not C++.  */
#ifdef __cplusplus
#define __EMS_BEGIN_DECLS extern "C" {
#define __EMS_END_DECLS }
#else
#define __EMS_BEGIN_DECLS
#define __EMS_END_DECLS
#endif
#endif

// qt5/qtbase/src/corelib/global/qglobal.h

#define MSF_EMS_NULLPTR nullptr
#define MSF_EMS_DECL_EQ_DEFAULT noexcept = default
#define MSF_EMS_DECL_EQ_DELETE noexcept = delete
#define MSF_EMS_DECL_CONSTEXPR constexpr
#define MSF_EMS_CONSTEXPR const
#define MSF_EMS_DECL_OVERRIDE override
#define MSF_EMS_DECL_FINAL final
#define MSF_EMS_DECL_NOEXCEPT noexcept
#define MSF_EMS_DECL_NOEXCEPT_EXPR(x) noexcept(x)
#define MSF_EMS_FUNC_INFO __PRETTY_FUNCTION__
#define MSF_EMS_FOREVER for (;;)
#define MSF_EMS_REQUIRED_RESULT [[nodiscard]]
#define MSF_EMS_REQUIRED_RESULT_MSG(MSG) [[nodiscard(MSG)]]
#define MSF_EMS_DEPRECATED [[deprecated]]
#define MSF_EMS_DEPRECATED_MSG(MSG) [[deprecated(MSG)]]
#define MSF_EMS_MAYBE_UNUSED [[maybe_unused]]
#define MSF_EMS_UNUSED_ARG(x)

#define Q_D(Class) Class##Private *const d = d_func()
#define Q_Q(Class) Class *const q = q_func()
/*
   Some classes do not permit copies to be made of an object. These
   classes contains a private copy constructor and assignment
   operator to disable copying (the compiler gives an error message).
 */

#define Q_DEFAULT_COPY_ASSIGN(Class)                                                                                   \
        Class(const Class &) MSF_EMS_DECL_EQ_DEFAULT;                                                                  \
        Class &operator=(Class &&) MSF_EMS_DECL_EQ_DEFAULT;

#define Q_DEFAULT_MOVE(Class)                                                                                          \
        Class(Class &&) MSF_EMS_DECL_EQ_DEFAULT;                                                                       \
        Class &operator=(Class &&) MSF_EMS_DECL_EQ_DEFAULT;

#define Q_DEFAULT_COPY(Class)                                                                                          \
        Class(const Class &) MSF_EMS_DECL_EQ_DEFAULT;                                                                  \
        Class &operator=(const Class &) MSF_EMS_DECL_EQ_DEFAULT;

#define Q_DISABLE_COPY_ASSIGN(Class)                                                                                   \
        Class(const Class &) MSF_EMS_DECL_EQ_DELETE;                                                                   \
        Class &operator=(Class &&) MSF_EMS_DECL_EQ_DELETE;

#define Q_DISABLE_COPY(Class)                                                                                          \
        Class(const Class &) MSF_EMS_DECL_EQ_DELETE;                                                                   \
        Class &operator=(const Class &) MSF_EMS_DECL_EQ_DELETE;

#define Q_DISABLE_MOVE(Class)                                                                                          \
        Class(Class &&) MSF_EMS_DECL_EQ_DELETE;                                                                        \
        Class &operator=(Class &&) MSF_EMS_DECL_EQ_DELETE;

#define Q_DISABLE_COPY_MOVE(Class)                                                                                     \
        Q_DISABLE_COPY(Class)                                                                                          \
        Q_DISABLE_MOVE(Class)

#define Q_DEFAULT_COPY_MOVE(Class)                                                                                     \
        Q_DEFAULT_COPY(Class)                                                                                          \
        Q_DEFAULT_MOVE(Class)

#define Q_NOT_INSTANTIABLE(Class)                                                                                      \
    private:                                                                                                           \
        Class() MSF_EMS_DECL_EQ_DELETE;                                                                                \
        ~Class() MSF_EMS_DECL_EQ_DELETE;

#define Q_PACKAGE(Class)                                                                                               \
        Q_NOT_INSTANTIABLE(Class)                                                                                      \
        Q_DISABLE_COPY_MOVE(Class)

#define Q_DECLARE_PUBLIC(Class)                                                                                        \
        inline Class *q_func()                                                                                         \
        {                                                                                                              \
                return static_cast<Class *>(q_ptr);                                                                    \
        }                                                                                                              \
        inline const Class *q_func() const                                                                             \
        {                                                                                                              \
                return static_cast<const Class *>(q_ptr);                                                              \
        }                                                                                                              \
        friend class Class;
