#ifndef COM_GITLAB_CORP_WABTEC_MSF_DHS_EMS_LAUNCHER_VERSION_HPP
#define COM_GITLAB_CORP_WABTEC_MSF_DHS_EMS_LAUNCHER_VERSION_HPP

#include <com/gitlab/corp/wabtec/msf/dhs/ems/logging/LoggingService.hpp>

namespace com::gitlab::corp::wabtec::msf::dhs::ems::launcher
{
class Version {
        LOG4CXX_DECLARE_STATIC_LOGGER
    public:
        Version() noexcept;

        Version(const Version &) = default;

        Version(Version &&) = default;

        Version &operator=(const Version &) = default;

        Version &operator=(Version &&) = default;

        virtual ~Version() noexcept;

    protected:
    private:
};
} // namespace com::gitlab::corp::wabtec::msf::dhs::ems::launcher
#endif