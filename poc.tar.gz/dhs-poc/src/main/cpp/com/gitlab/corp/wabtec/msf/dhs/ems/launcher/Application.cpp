#include <iostream>
#include <com/gitlab/corp/wabtec/msf/dhs/ems/launcher/Application.hpp>

using namespace com::gitlab::corp::wabtec::msf::dhs::ems::launcher;
using namespace com::gitlab::corp::wabtec::msf::dhs::ems::launcher::logging;
log4cxx::LoggerPtr Application::logger =
        log4cxx::Logger::getLogger(std::string("com.gitlab.corp.wabtec.msf.dhs.ems.launcher.Application"));
//std::cout << __func__ << __FUNCTION__ << __PRETTY_FUNCTION__ << std::endl;
Application::Application() noexcept : m_loggingService{ std::make_unique<LoggingService>() }
{
        LOG4CXX_TRACE(logger, __LOG4CXX_FUNC__);
}

Application::~Application() noexcept
{
        LOG4CXX_TRACE(logger, __LOG4CXX_FUNC__);
}
