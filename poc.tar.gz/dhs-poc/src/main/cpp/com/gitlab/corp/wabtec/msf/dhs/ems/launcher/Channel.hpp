#ifndef COM_GITLAB_CORP_WABTEC_MSF_DHS_EMS_LAUNCHER_CHANNEL_HPP
#define COM_GITLAB_CORP_WABTEC_MSF_DHS_EMS_LAUNCHER_CHANNEL_HPP
#include <com/gitlab/corp/wabtec/msf/dhs/ems/launcher/Handle.hpp>
namespace com::gitlab::corp::wabtec::msf::dhs::ems::launcher
{

template <typename Data, typename Policy> class Channel {
    public:
        Channel(const Channel &) = default;
        Channel(Channel &&) = default;
        Channel &operator=(const Channel &) = default;
        Channel &operator=(Channel &&) = default;

        /*!
   * @brief Publish data to a channel.  This data is *copied* on publish.
   * @param[in] priority - the priority to use for post
   * @param[in,out] data - the data to publish
   */
        void publish(int priority, const Data &data);

    protected:
    private:
        Channel() noexcept;
        virtual ~Channel() noexcept;
};
} // namespace com::gitlab::corp::wabtec::msf::dhs::ems::launcher
#endif