
#include <com/gitlab/corp/wabtec/msf/dhs/ems/launcher/QueuedHandler.hpp>

using namespace com::gitlab::corp::wabtec::msf::dhs::ems::launcher;

QueuedHandler::QueuedHandler() noexcept
{
}

QueuedHandler::~QueuedHandler() noexcept
{
}
