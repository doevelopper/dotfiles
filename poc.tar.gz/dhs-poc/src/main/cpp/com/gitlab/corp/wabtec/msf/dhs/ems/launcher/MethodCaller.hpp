#ifndef COM_GITLAB_CORP_WABTEC_MSF_DHS_EMS_LAUNCHER_METHODCALLER_HPP
#define COM_GITLAB_CORP_WABTEC_MSF_DHS_EMS_LAUNCHER_METHODCALLER_HPP

namespace com::gitlab::corp::wabtec::msf::dhs::ems::launcher
{
class MethodCaller {
    public:
        MethodCaller() noexcept;
        MethodCaller(const MethodCaller &) = default;
        MethodCaller(MethodCaller &&) = default;
        MethodCaller &operator=(const MethodCaller &) = default;
        MethodCaller &operator=(MethodCaller &&) = default;
        virtual ~MethodCaller() noexcept;

    protected:
    private:
};
} // namespace com::gitlab::corp::wabtec::msf::dhs::ems::launcher
#endif