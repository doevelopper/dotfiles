#ifndef COM_GITLAB_CORP_WABTEC_MSF_DHS_EMS_LAUNCHER_IOPTIONSMANAGER_HPP
#define COM_GITLAB_CORP_WABTEC_MSF_DHS_EMS_LAUNCHER_IOPTIONSMANAGER_HPP

namespace com::gitlab::corp::wabtec::msf::dhs::ems::launcher
{
class IOptionsManager {
    public:
        IOptionsManager() noexcept;
        IOptionsManager(const IOptionsManager &) = default;
        IOptionsManager(IOptionsManager &&) = default;
        IOptionsManager &operator=(const IOptionsManager &) = default;
        IOptionsManager &operator=(IOptionsManager &&) = default;
        virtual ~IOptionsManager() noexcept;

    protected:
    private:
};
} // namespace com::gitlab::corp::wabtec::msf::dhs::ems::launcher
#endif