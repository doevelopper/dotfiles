
#include <com/gitlab/corp/wabtec/msf/dhs/ems/launcher/AbstractQueuedHandler.hpp>

using namespace com::gitlab::corp::wabtec::msf::dhs::ems::launcher;

AbstractQueuedHandler::AbstractQueuedHandler() noexcept
{
}

AbstractQueuedHandler::~AbstractQueuedHandler() noexcept
{
}
