
#include <apr-1/apr.h>
#include <log4cxx/appender.h>
#include <log4cxx/basicconfigurator.h>
#include <log4cxx/consoleappender.h>
#include <log4cxx/fileappender.h>
#include <log4cxx/helpers/exception.h>
#include <log4cxx/logger.h>
#include <log4cxx/logmanager.h>
#include <log4cxx/logstring.h> // has typedefed string type used in log4cxx
// #include <log4cxx/net/socketappender.h>
#include <stdexcept>
#include <string>
#include <log4cxx/nt/nteventlogappender.h>
#include <log4cxx/nt/outputdebugstringappender.h> // NT OUTPUTDEBUGSTRING Appender
#include <log4cxx/patternlayout.h>
#include <log4cxx/propertyconfigurator.h>
#include <log4cxx/rolling/fixedwindowrollingpolicy.h>
#include <log4cxx/rolling/rollingfileappender.h>
#include <log4cxx/rolling/rollingpolicy.h>
#include <log4cxx/rolling/rollingpolicybase.h>
#include <log4cxx/rolling/sizebasedtriggeringpolicy.h>
#include <log4cxx/rolling/triggeringpolicy.h>
#include <log4cxx/simplelayout.h>
#include <log4cxx/xml/domconfigurator.h>

#include <com/gitlab/corp/wabtec/msf/dhs/ems/logging/LoggingService.hpp>

#include <iostream>
using namespace com::gitlab::corp::wabtec::msf::dhs::ems::launcher::logging;

LoggingService::LoggingService() noexcept
{
        log4cxx::PatternLayoutPtr layout(new log4cxx::PatternLayout(
                              LOG4CXX_STR("%Y %d{yyyy-MM-dd HH:mm:ss.SSS} [%-6p] - [%15.15t] - %-35c{1.} -- %m%n")));
        log4cxx::ConsoleAppenderPtr consoleAppender(new log4cxx::ConsoleAppender(layout));
        log4cxx::helpers::Pool pool;
        consoleAppender->activateOptions(pool);
        log4cxx::BasicConfigurator::configure(consoleAppender);
        log4cxx::Logger::getRootLogger()->setLevel(/*LOG_LEVEL*/ true ? log4cxx::Level::getTrace() :
                                                                        log4cxx::Level::getInfo());

        log4cxx::LogManager::getLoggerRepository()->setConfigured(true);

        LOG4CXX_INFO(log4cxx::Logger::getRootLogger(), "----START LOGGING-----");
        log4cxx::LogManager::getLoggerRepository()->getRootLogger()->info("Internal logging system configured.");
        LOG4CXX_TRACE(log4cxx::Logger::getRootLogger(),
                      "Logger initialized with " << log4cxx::Logger::getRootLogger()->getAllAppenders().size()
                                                 << " Appenders");
}

LoggingService::~LoggingService() noexcept
{
        LOG4CXX_TRACE(log4cxx::Logger::getRootLogger(), __LOG4CXX_FUNC__);

        if (log4cxx::LogManager::getLoggerRepository()->isConfigured()) {
                LOG4CXX_INFO(log4cxx::Logger::getRootLogger(), "---- END LOGGING -----");
        }

        log4cxx::LogManager::shutdown();
}
