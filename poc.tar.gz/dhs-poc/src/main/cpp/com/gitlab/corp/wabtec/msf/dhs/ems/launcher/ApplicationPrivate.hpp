#ifndef COM_GITLAB_CORP_WABTEC_MSF_DHS_EMS_LAUNCHER_APPLICATIONPRIVATE_HPP
#define COM_GITLAB_CORP_WABTEC_MSF_DHS_EMS_LAUNCHER_APPLICATIONPRIVATE_HPP

#include <typeindex>
#include <unordered_map>

#include <boost/algorithm/string.hpp>
#include <boost/filesystem.hpp>
#include <boost/program_options.hpp>
#include <boost/asio/signal_set.hpp>

namespace com::gitlab::corp::wabtec::msf::dhs::ems::launcher
{
class ApplicationPrivate {
    public:
        ApplicationPrivate() noexcept;
        ApplicationPrivate(const ApplicationPrivate &) = default;
        ApplicationPrivate(ApplicationPrivate &&) = default;
        ApplicationPrivate &operator=(const ApplicationPrivate &) = default;
        ApplicationPrivate &operator=(ApplicationPrivate &&) = default;
        virtual ~ApplicationPrivate() noexcept;

        boost::program_options::options_description applicationOptions;
        boost::program_options::options_description configurationOptions;
        boost::program_options::variables_map standardOptions;

        boost::filesystem::path _data_dir{ "data-dir" };
        boost::filesystem::path _config_dir{ "config-dir" };
        boost::filesystem::path _logging_conf{ "logging.json" };
        boost::filesystem::path _config_file_name;

        std::uint64_t version = 0;
        std::string versionStr = "appbase_version_string";
        std::string fullVersionStr = "appbase_version_string";

        std::atomic_bool isQuiting{ false };

        using any_type_compare_map =
                std::unordered_map<std::type_index, std::function<bool(const boost::any &a, const boost::any &b)>>;
        any_type_compare_map _any_compare_map;

    protected:
    private:
};
} // namespace com::gitlab::corp::wabtec::msf::dhs::ems::launcher
#endif