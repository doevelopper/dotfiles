#ifndef COM_GITLAB_CORP_WABTEC_MSF_DHS_EMS_LAUNCHER_IPLUGIN_HPP
#define COM_GITLAB_CORP_WABTEC_MSF_DHS_EMS_LAUNCHER_IPLUGIN_HPP

#include <cstdint>
#include <string>

#include <boost/preprocessor/seq/for_each.hpp>
#include <boost/program_options.hpp>

namespace com::gitlab::corp::wabtec::msf::dhs::ems::launcher
{
class IPlugin {
    public:
        enum class State : std::uint8_t {
                REGISTERED, ///< the plugin is constructed but doesn't do anything
                INITIALIZED, ///< the plugin has initialized any state required but is idle
                STARTED, ///< the plugin is actively running
                STOPPED ///< the plugin is no longer running
        };
        IPlugin() noexcept;
        IPlugin(const IPlugin &) = default;
        IPlugin(IPlugin &&) = default;
        IPlugin &operator=(const IPlugin &) = default;
        IPlugin &operator=(IPlugin &&) = default;
        virtual ~IPlugin() noexcept;

        virtual void handleSignalHangUp() = 0;
        virtual const std::string &name() const = 0;
        virtual void startup() = 0;
        virtual void shutdown() = 0;
        virtual State state() const = 0;
        virtual void options(boost::program_options::options_description &command,
                             boost::program_options::options_description &config) = 0;
        virtual void initialize(const boost::program_options::variables_map &options) = 0;

    protected:
    private:
};
} // namespace com::gitlab::corp::wabtec::msf::dhs::ems::launcher
#endif