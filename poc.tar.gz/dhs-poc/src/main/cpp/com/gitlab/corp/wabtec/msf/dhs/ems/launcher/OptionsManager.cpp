
#include <com/gitlab/corp/wabtec/msf/dhs/ems/launcher/OptionsManager.hpp>

using namespace com::gitlab::corp::wabtec::msf::dhs::ems::launcher;

OptionsManager::OptionsManager() noexcept
{
}

OptionsManager::~OptionsManager() noexcept
{
}
