
#include <com/gitlab/corp/wabtec/msf/dhs/ems/launcher/Handle.hpp>

using namespace com::gitlab::corp::wabtec::msf::dhs::ems::launcher;

Handle::Handle() noexcept
{
}

Handle::~Handle() noexcept
{
}
