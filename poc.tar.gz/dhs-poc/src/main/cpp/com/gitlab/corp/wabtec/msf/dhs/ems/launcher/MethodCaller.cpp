
#include <com/gitlab/corp/wabtec/msf/dhs/ems/launcher/MethodCaller.hpp>

using namespace com::gitlab::corp::wabtec::msf::dhs::ems::launcher;

MethodCaller::MethodCaller() noexcept
{
}

MethodCaller::~MethodCaller() noexcept
{
}
