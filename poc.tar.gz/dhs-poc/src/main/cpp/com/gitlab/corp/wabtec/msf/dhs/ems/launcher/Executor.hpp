#ifndef COM_GITLAB_CORP_WABTEC_MSF_DHS_EMS_LAUNCHER_EXECUTOR_HPP
#define COM_GITLAB_CORP_WABTEC_MSF_DHS_EMS_LAUNCHER_EXECUTOR_HPP

namespace com::gitlab::corp::wabtec::msf::dhs::ems::launcher
{
class Executor {
    public:
        Executor() noexcept;
        Executor(const Executor &) = default;
        Executor(Executor &&) = default;
        Executor &operator=(const Executor &) = default;
        Executor &operator=(Executor &&) = default;
        virtual ~Executor() noexcept;

    protected:
    private:
};
} // namespace com::gitlab::corp::wabtec::msf::dhs::ems::launcher
#endif