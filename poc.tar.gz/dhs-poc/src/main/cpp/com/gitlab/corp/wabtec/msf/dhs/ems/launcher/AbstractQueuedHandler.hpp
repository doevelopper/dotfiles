#ifndef COM_GITLAB_CORP_WABTEC_MSF_DHS_EMS_LAUNCHER_ABSTRACTQUEUEDHANDLER_HPP
#define COM_GITLAB_CORP_WABTEC_MSF_DHS_EMS_LAUNCHER_ABSTRACTQUEUEDHANDLER_HPP

namespace com::gitlab::corp::wabtec::msf::dhs::ems::launcher
{
class AbstractQueuedHandler {
    public:
        AbstractQueuedHandler() noexcept;
        AbstractQueuedHandler(const AbstractQueuedHandler &) = default;
        AbstractQueuedHandler(AbstractQueuedHandler &&) = default;
        AbstractQueuedHandler &operator=(const AbstractQueuedHandler &) = default;
        AbstractQueuedHandler &operator=(AbstractQueuedHandler &&) = default;
        virtual ~AbstractQueuedHandler() noexcept;

    protected:
    private:
};
} // namespace com::gitlab::corp::wabtec::msf::dhs::ems::launcher
#endif