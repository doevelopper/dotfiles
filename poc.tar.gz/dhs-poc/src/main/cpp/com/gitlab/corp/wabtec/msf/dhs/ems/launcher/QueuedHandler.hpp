#ifndef COM_GITLAB_CORP_WABTEC_MSF_DHS_EMS_LAUNCHER_QUEUEDHANDLER_HPP
#define COM_GITLAB_CORP_WABTEC_MSF_DHS_EMS_LAUNCHER_QUEUEDHANDLER_HPP

namespace com::gitlab::corp::wabtec::msf::dhs::ems::launcher
{
class QueuedHandler {
    public:
        QueuedHandler() noexcept;
        QueuedHandler(const QueuedHandler &) = default;
        QueuedHandler(QueuedHandler &&) = default;
        QueuedHandler &operator=(const QueuedHandler &) = default;
        QueuedHandler &operator=(QueuedHandler &&) = default;
        virtual ~QueuedHandler() noexcept;

    protected:
    private:
};
} // namespace com::gitlab::corp::wabtec::msf::dhs::ems::launcher
#endif