
#include <com/gitlab/corp/wabtec/msf/dhs/ems/launcher/IPlugin.hpp>

using namespace com::gitlab::corp::wabtec::msf::dhs::ems::launcher;

IPlugin::IPlugin() noexcept
{
}

IPlugin::~IPlugin() noexcept
{
}
