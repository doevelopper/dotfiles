#ifndef COM_GITLAB_CORP_WABTEC_MSF_DHS_EMS_LAUNCHER_METHOD_HPP
#define COM_GITLAB_CORP_WABTEC_MSF_DHS_EMS_LAUNCHER_METHOD_HPP

namespace com::gitlab::corp::wabtec::msf::dhs::ems::launcher
{
class Method {
    public:
        Method() noexcept;
        Method(const Method &) = default;
        Method(Method &&) = default;
        Method &operator=(const Method &) = default;
        Method &operator=(Method &&) = default;
        virtual ~Method() noexcept;

    protected:
    private:
};
} // namespace com::gitlab::corp::wabtec::msf::dhs::ems::launcher
#endif