
#include <com/gitlab/corp/wabtec/msf/dhs/ems/launcher/Channel.hpp>

using namespace com::gitlab::corp::wabtec::msf::dhs::ems::launcher;

template <typename Data, typename Policy> Channel<Data, Policy>::Channel() noexcept
{
}

template <typename Data, typename Policy> Channel<Data, Policy>::~Channel() noexcept
{
}
