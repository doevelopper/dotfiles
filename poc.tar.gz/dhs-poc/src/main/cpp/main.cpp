
#include <cstdlib>
#include <iostream>
#include <memory>

#include <com/gitlab/corp/wabtec/msf/dhs/ems/launcher/Application.hpp>

using namespace com::gitlab::corp::wabtec::msf::dhs::ems::launcher;
// uuidgen | sed -r 's/(..)-?/0x\1,/g' | sed -e 's/^/static constexpr DHS_SW_UUID dhs_sw_id
// {/' -e 's/,$/}/'
/*!
 * @brief  Main entry poinbt of the application
 * @param[in] argc number of string arguments passed via argv
 * @param[in,out] argv array to command line arguments as strings
 *             (an array of character pointers)
 * @return The completion status code (zero indicates success)
 */
int main(
    [[maybe_unused]] int argc,
    [[maybe_unused]] char *argv[]
)
{
        std::uint8_t runStatus = EXIT_FAILURE;
        
//        try {
          std::unique_ptr<Application> application = std::make_unique<Application>();

//        } catch (const std::exception &e) {
//                std::cerr << e.what() << std::endl;
//        } catch (...) {
//                std::cerr << "unknown exception\n";
//        }
//
//        if (runStatus != EXIT_SUCCESS) {
//                std::cerr << "FAILED!" << std::endl;
//        } else {
//                std::cout << "Hello, World!" << std::endl;
//        }

        return (runStatus == 0 ? EXIT_SUCCESS : EXIT_FAILURE);
}